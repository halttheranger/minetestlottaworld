minetest.register_on_newplayer(function(player)
    --print("on_newplayer")
    if minetest.setting_getbool("give_initial_stuff") then
        minetest.log("action", "Giving initial stuff to player "..player:get_player_name())
        player:get_inventory():add_item('main', 'shooter:handgun')
        player:get_inventory():add_item('main', 'shooter:sniper')
        player:get_inventory():add_item('main', 'default:apple 99')
        player:get_inventory():add_item('main', 'shooter:ammo 15')
        player:get_inventory():add_item('main', 'cars:car_midnight')
        player:get_inventory():add_item('main', 'default:sword_steel')
    end
end)
