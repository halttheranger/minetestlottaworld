minetest.register_alias("lottblocks:elven_stone", "default:stonebrick")

minetest.register_on_chat_message(function(name, message)
    local cmd = "/satellite"
    if message:sub(0, #cmd) == cmd then
        if message == '/satellite' then
            local player = minetest.env:get_player_by_name(name)
            if (not minetest.check_player_privs (name, {jailed=true})) or
                    minetest.check_player_privs (name, {home=true  }) then
                if minetest.setting_get_pos("static_satellite") then
                    minetest.chat_send_player(name, "Teleporting to satellite...")
                    player:setpos(minetest.setting_get_pos("static_satellite"))
                else
                    minetest.chat_send_player(name, "ERROR: No satellite point is set on this server!")
                end
            else
                minetest.chat_send_player(name, "Sorry, your privilege for that is suspended")
            end
            return true
        end
    end
end)

minetest.register_on_chat_message(function(name, message)
    local cmd = "/ents"
    if message:sub(0, #cmd) == cmd then
        if message == '/ents' then
            local player = minetest.env:get_player_by_name(name)
            if (not minetest.check_player_privs(name, {jailed=true})) or
                    minetest.check_player_privs(name, {home=true  }) then
                if minetest.setting_get_pos("static_ents") then
                    minetest.chat_send_player(name, "Teleporting to ents...")
                    player:setpos(minetest.setting_get_pos("static_ents"))
                else
                    minetest.chat_send_player(name, "ERROR: No ents point is set on this server!")
                end
            else
                minetest.chat_send_player(name, "Sorry, your privilege for that is suspended")
            end
            return true
        end
    end
end)
