

This tool let you change metadata in node / blocks witha simple tool
Requires server priv
ownerhack:tool or hacktool