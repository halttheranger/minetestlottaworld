doors = {}

-- Registers a door - REDEFINITION ONLY | DOORS MOD MUST HAVE BEEN LOADED BEFORE
--  name: The name of the door
--  def: a table with the folowing fields:
--    description
--    inventory_image
--    groups
--    tiles_bottom: the tiles of the bottom part of the door {front, side}
--    tiles_top: the tiles of the bottom part of the door {front, side}
--    If the following fields are not defined the default values are used
--    node_box_bottom
--    node_box_top
--    selection_box_bottom
--    selection_box_top
--    only_placer_can_open: if true only the player who placed the door can
--                          open it

function doors:register_door(name, def)
    def.groups.not_in_creative_inventory = 1
    
    local box = {{-0.5, -0.5, -0.5,   0.5, 0.5, -0.5+1.5/16}}
    
    if not def.node_box_bottom then
        def.node_box_bottom = box
    end
    if not def.node_box_top then
        def.node_box_top = box
    end
    if not def.selection_box_bottom then
        def.selection_box_bottom= box
    end
    if not def.selection_box_top then
        def.selection_box_top = box
    end
    
    local tt = def.tiles_top
    local tb = def.tiles_bottom
    
    local function after_dig_node(pos, name)
        if minetest.get_node(pos).name == name then
            minetest.remove_node(pos)
        end
    end

    local function on_rightclick(pos, dir, check_name, replace, replace_dir, params)
        pos.y = pos.y+dir
        if not minetest.get_node(pos).name == check_name then
            return
        end
        local p2 = minetest.get_node(pos).param2
        p2 = params[p2+1]
        
        local meta = minetest.get_meta(pos):to_table()
        minetest.set_node(pos, {name=replace_dir, param2=p2})
        minetest.get_meta(pos):from_table(meta)
        
        pos.y = pos.y-dir
        meta = minetest.get_meta(pos):to_table()
        minetest.set_node(pos, {name=replace, param2=p2})
        minetest.get_meta(pos):from_table(meta)
    end

    local function on_mesecons_signal_open (pos, node)
        on_rightclick(pos, 1, name.."_t_1", name.."_b_2", name.."_t_2", {1,2,3,0})
    end

    local function on_mesecons_signal_close (pos, node)
        on_rightclick(pos, 1, name.."_t_2", name.."_b_1", name.."_t_1", {3,0,1,2})
    end
    
    local function check_player_priv(pos, player)
        if not def.only_placer_can_open then
            return true
        end
        local meta = minetest.get_meta(pos)
        local pn = player:get_player_name()
        return meta:get_string("doors_owner") == pn
    end
    
    minetest.register_node(":"..name.."_b_1", {
        tiles = {tb[2], tb[2], tb[2], tb[2], tb[1], tb[1].."^[transformfx"},
        paramtype = "light",
        paramtype2 = "facedir",
        drop = name,
        drawtype = "nodebox",
        node_box = {
            type = "fixed",
            fixed = def.node_box_bottom
        },
        selection_box = {
            type = "fixed",
            fixed = def.selection_box_bottom
        },
        groups = def.groups,
        
        after_dig_node = function(pos, oldnode, oldmetadata, digger)
            pos.y = pos.y+1
            after_dig_node(pos, name.."_t_1")
        end,
        
        on_rightclick = function(pos, node, puncher)
            if check_player_priv(pos, puncher) then
                on_rightclick(pos, 1, name.."_t_1", name.."_b_2", name.."_t_2", {1,2,3,0})
            end
        end,

        mesecons = {effector = {
            action_on  = on_mesecons_signal_open
        }},
        
        can_dig = check_player_priv,
    })
    
    minetest.register_node(":"..name.."_b_2", {
        tiles = {tb[2], tb[2], tb[2], tb[2], tb[1].."^[transformfx", tb[1]},
        paramtype = "light",
        paramtype2 = "facedir",
        drop = name,
        drawtype = "nodebox",
        node_box = {
            type = "fixed",
            fixed = def.node_box_bottom
        },
        selection_box = {
            type = "fixed",
            fixed = def.selection_box_bottom
        },
        groups = def.groups,
        
        after_dig_node = function(pos, oldnode, oldmetadata, digger)
            pos.y = pos.y+1
            after_dig_node(pos, name.."_t_2")
        end,
        
        on_rightclick = function(pos, node, puncher)
            if check_player_priv(pos, puncher) then
                on_rightclick(pos, 1, name.."_t_2", name.."_b_1", name.."_t_1", {3,0,1,2})
            end
        end,

        mesecons = {effector = {
            action_off = on_mesecons_signal_close
        }},
        
        can_dig = check_player_priv,
    })
end

doors:register_door("doors:door_wood", {
    description = "Wooden Door",
    inventory_image = "door_wood.png",
    groups = {snappy=1,choppy=2,oddly_breakable_by_hand=2,flammable=2,door=1},
    tiles_bottom = {"door_wood_b.png", "door_brown.png"},
    tiles_top = {"door_wood_a.png", "door_brown.png"},
    sounds = default.node_sound_wood_defaults(),
})

doors:register_door("doors:door_steel", {
    description = "Steel Door",
    inventory_image = "door_steel.png",
    groups = {snappy=1,bendy=2,cracky=1,melty=2,level=2,door=1},
    tiles_bottom = {"door_steel_b.png", "door_grey.png"},
    tiles_top = {"door_steel_a.png", "door_grey.png"},
    only_placer_can_open = true,
    sounds = default.node_sound_stone_defaults(),
})
