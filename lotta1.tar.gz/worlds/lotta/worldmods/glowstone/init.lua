minetest.register_node("glowstone:glowstone", {
    description = "Glowstone",
    tiles = {"glowstone_glowstone.png"},
    is_ground_content = true,
    light_source = 12,
    groups = {cracky=3, oddly_breakable_by_hand=3},
    sounds = default.node_sound_glass_defaults(),
})

minetest.register_craft({
    output = 'glowstone:glowstone',
    recipe = {
        {'', 'group:stone', ''},
        {'group:stone', 'default:torch', 'group:stone'},
        {'', 'group:stone', ''},
    }
})
