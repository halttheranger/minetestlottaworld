 ______   __   __  _______  ___      _______  _______  ______    _______ 
|      | |  | |  ||   _   ||   |    |       ||       ||    _ |  |       |
|  _    ||  | |  ||  |_|  ||   |    |    _  ||   _   ||   | ||  |_     _|
| | |   ||  |_|  ||       ||   |    |   |_| ||  | |  ||   |_||_   |   |  
| |_|   ||       ||       ||   |___ |    ___||  |_|  ||    __  |  |   |  
|       ||       ||   _   ||       ||   |    |       ||   |  | |  |   |  
|______| |_______||__| |__||_______||___|    |_______||___|  |_|  |___|  

BY:             bas080
DESCRIPTION:    Dual port teleportation inspired by Zeg9's version
VERSION:        2.0
LICENSE:        WTFPL
FORUM:          http://forum.minetest.net/viewtopic.php?pid=76281

Changelog
---------
2.0
* Buildport node added
* Chat message removed (sound should give enough feedback)
* Removing portal will remove connected portal.

1.2
* Made sound audible to only a certain distance (better for multiplayer)

1.1
* Improvedsound play on (punch) use

1.0
* Improved infotext
* Added linked soundeffect

0.5
* Give portals a name
* Infotext which tells player to where portal leads
* Teleport nodes that work in pairs
