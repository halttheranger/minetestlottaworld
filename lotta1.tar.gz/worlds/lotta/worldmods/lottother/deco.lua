-- DEFAULT BLOCKS

minetest.register_node("lottother:coalblock", {
    description = "Coal Plated Block",
    tiles = {"default_coal_block.png"},
    is_ground_content = true,
    groups = {cracky=3},
    sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("lottother:steelblock", {
    description = "Steel Plated Block",
    tiles = {"default_steel_block.png"},
    is_ground_content = true,
    groups = {cracky=1,level=2},
    sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("lottother:copperblock", {
    description = "Copper Plated Block",
    tiles = {"default_copper_block.png"},
    is_ground_content = true,
    groups = {cracky=1,level=2},
    sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("lottother:bronzeblock", {
    description = "Bronze Plated Block",
    tiles = {"default_bronze_block.png"},
    is_ground_content = true,
    groups = {cracky=1,level=2},
    sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("lottother:meseblock", {
    description = "Mese Plated Block",
    tiles = {"default_mese_block.png"},
    is_ground_content = true,
    groups = {cracky=1,level=2},
    sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("lottother:goldblock", {
    description = "Gold Plated Block",
    tiles = {"default_gold_block.png"},
    is_ground_content = true,
    groups = {cracky=1},
    sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("lottother:diamondblock", {
    description = "Diamond Plated Block",
    tiles = {"default_diamond_block.png"},
    is_ground_content = true,
    groups = {cracky=1,level=3},
    sounds = default.node_sound_stone_defaults(),
})

-- LOTTORES BLOCKS

minetest.register_node("lottother:silver_block", {
    description = "Silver Plated Block",
    tiles = {"lottores_silver_block.png"},
    is_ground_content = true,
    groups = {cracky=1,level=2},
    sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("lottother:tin_block", {
    description = "Tin Plated Block",
    tiles = {"lottores_tin_block.png"},
    is_ground_content = true,
    groups = {cracky=1},
    sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("lottother:lead_block", {
    description = "Lead Plated Block",
    tiles = {"lottores_lead_block.png"},
    is_ground_content = true,
    groups = {cracky=1},
    sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("lottother:mithril_block", {
    description = "Mithril Plated Block",
    tiles = {"lottores_mithril_block.png"},
    is_ground_content = true,
    groups = {cracky=1,level=2},
    sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("lottother:galvorn_block", {
    description = "Galvorn Plated Block",
    tiles = {"lottores_galvorn_block.png"},
    is_ground_content = true,
    groups = {cracky=1,level=2,forbidden=1},
    sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("lottother:tilkal_block", {
    description = "Tilkal Plated Block",
    tiles = {"lottores_tilkal.png"},
    sounds = default.node_sound_defaults(),
    groups = {forbidden=1},
})


local ingredients = {'default:coal_lump', 'default:steel_ingot', 'default:copper_ingot', 'default:bronze_ingot', 'default:mese_crystal', 'default:gold_ingot', 'default:diamond', 'lottores:silver_ingot', 'lottores:tin_ingot', 'lottores:lead_ingot', 'lottores:mithril_ingot', 'lottores:galvorn_ingot', 'lottores:tilkal_ingot'}

local output = {'lottother:coalblock', 'lottother:steelblock', 'lottother:copperblock', 'lottother:bronzeblock', 'lottother:meseblock', 'lottother:goldblock', 'lottother:diamondblock', 'lottother:silver_block', 'lottother:tin_block', 'lottother:lead_block', 'lottother:mithril_block', 'lottother:galvorn_block', 'lottother:tilkal_block'}

for i=1, 13 do
minetest.register_craft({
    output = output[i],
    recipe = {
        {'default:cobble', 'default:cobble', "default:cobble"},
        {'default:cobble', ingredients[i], "default:cobble"},
        {'default:cobble', 'default:cobble', "default:cobble"}
    },
    --print("[lottother] [deco.lua] Crafting for ".. output[i] .." loaded!"),
    i = i + 1
})
end

for i=1, 13 do
minetest.register_craft({
    output = "default:cobble",
    recipe = {
        {output[i]},
    },
    --print("[lottother] [deco.lua] Crafting Back for ".. output[i] .." loaded!"),
    i = i + 1
})
end