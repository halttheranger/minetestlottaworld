------------------------------------------------------
-- Darkage mod by MasterGollum, addi and CraigyDavi --
------------------------------------------------------

dofile(minetest.get_modpath("darkage").."/nodes.lua")
dofile(minetest.get_modpath("darkage").."/craftitems.lua")
dofile(minetest.get_modpath("darkage").."/crafts.lua")
dofile(minetest.get_modpath("darkage").."/mapgen.lua")
dofile(minetest.get_modpath("darkage").."/stairs.lua")
dofile(minetest.get_modpath("darkage").."/aliases.lua")

--
-- Config
--

print ("Darkage [darkage] has loaded!")
