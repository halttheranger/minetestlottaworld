# Chatplus

**NOTE: Chatplus has split into two mods, chatplus and [email](https://github.com/rubenwardy/email)**

Adds ignoring, distance limiting (optional) and a swear filter (optional). Also provides a powerful API.

License: GPL 3.0 or later.

Created by rubenwardy.

## Chat commands

* /ignore [name] - ignore a player
* /unignore [name] - unignore a player

## HUD

This mod adds a new message icon to the HUD. If HUDs are not supported, no icon is added.
