-- Atomic Nuke Mod by halt_ 

function spawn_tnt(pos, entname)
    minetest.sound_play("nuke_ignite", {pos = pos,gain = 1.0,max_hear_distance = 8,})
    return minetest.add_entity(pos, entname)
end

function activate_if_tnt(nname, np, tnt_np, tntr)
    if nname == "atomic_nuke:wallbreak_tnt" or nname == "atomic_nuke:atomic_tnt" or nname == "atomic_nuke:hardcore_wallbreak_tnt" or nname == "atomic_nuke:hardcore_atomic_tnt" then
        local e = spawn_tnt(np, nname)
        e:setvelocity({x=(np.x - tnt_np.x)*3+(tntr / 4), y=(np.y - tnt_np.y)*3+(tntr / 3), z=(np.z - tnt_np.z)*3+(tntr / 4)})
    end
end

function do_tnt_physics(tnt_np,tntr)
    local objs = minetest.get_objects_inside_radius(tnt_np, tntr)
    for k, obj in pairs(objs) do
        local oname = obj:get_entity_name()
        local v = obj:getvelocity()
        local p = obj:getpos()
        if oname == "atomic_nuke:wallbreak_tnt" or oname == "atomic_nuke:atomic_tnt" or oname == "atomic_nuke:hardcore_wallbreak_tnt" or oname == "atomic_nuke:hardcore_atomic_tnt" then
            obj:setvelocity({x=(p.x - tnt_np.x) + (tntr / 2) + v.x, y=(p.y - tnt_np.y) + tntr + v.y, z=(p.z - tnt_np.z) + (tntr / 2) + v.z})
        else
            if v ~= nil then
                obj:setvelocity({x=(p.x - tnt_np.x) + (tntr / 4) + v.x, y=(p.y - tnt_np.y) + (tntr / 2) + v.y, z=(p.z - tnt_np.z) + (tntr / 4) + v.z})
            else
                if obj:get_player_name() ~= nil then
                    obj:set_hp(obj:get_hp() - 1)
                end
            end
        end
    end
end

-- Wallbreak TNT

minetest.register_craft({
	output = 'atomic_nuke:wallbreak_tnt 5',
	recipe = {
		{'','default:wood 1',''},
		{'default:coal_lump 1','default:steel_ingot 1','default:coal_lump 1'},
		{'','default:cobble 1',''}
	}
})

minetest.register_node("atomic_nuke:wallbreak_tnt", {
	tile_images = {"nuke_iron_tnt_top.png", "nuke_iron_tnt_bottom.png",
			"nuke_iron_tnt_side.png", "nuke_iron_tnt_side.png",
			"nuke_iron_tnt_side.png", "nuke_iron_tnt_side.png"},
	inventory_image = minetest.inventorycube("nuke_iron_tnt_top.png",
			"nuke_iron_tnt_side.png", "nuke_iron_tnt_side.png"),
	dug_item = '', -- Get nothing
	diggable = false,
	description = "Wallbreak TNT",
	mesecons = {
		effector = {
			action_on = function(pos, node)
				minetest.remove_node(pos)
				spawn_tnt(pos, node.name)
				nodeupdate(pos)
			end,
			action_off = function(pos, node) end,
			action_change = function(pos, node) end,
		},
	},
	on_punch = function(pos, node, puncher)
		minetest.remove_node(pos)
		spawn_tnt(pos, node.name)
		nodeupdate(pos)
	end,
})

local WALLBREAK_TNT_RANGE = 2
local WALLBREAK_TNT = {
	-- Static definition
	physical = true, -- Collides with things
	-- weight = 2,
	collisionbox = {-0.5,-0.5,-0.5, 0.5,0.5,0.5},
	visual = "cube",
	textures = {"nuke_iron_tnt_top.png", "nuke_iron_tnt_bottom.png",
			"nuke_iron_tnt_side.png", "nuke_iron_tnt_side.png",
			"nuke_iron_tnt_side.png", "nuke_iron_tnt_side.png"},
	-- Initial value for our timer
	timer = 0,
	-- Number of punches required to defuse
	health = 1,
	blinktimer = 0,
	blinkstatus = true,
}

function WALLBREAK_TNT:on_activate(staticdata)
	self.object:setvelocity({x=0, y=4, z=0})
	self.object:setacceleration({x=0, y=-10, z=0})
	self.object:settexturemod("^[brighten")
end

function WALLBREAK_TNT:on_step(dtime)
	self.timer = self.timer + dtime
	self.blinktimer = self.blinktimer + dtime
    if self.timer>5 then
        self.blinktimer = self.blinktimer + dtime
        if self.timer>8 then
            self.blinktimer = self.blinktimer + dtime
            self.blinktimer = self.blinktimer + dtime
        end
    end
	if self.blinktimer > 0.5 then
		self.blinktimer = self.blinktimer - 0.5
		if self.blinkstatus then
			self.object:settexturemod("")
		else
			self.object:settexturemod("^[brighten")
		end
		self.blinkstatus = not self.blinkstatus
	end
	if self.timer > 10 then
		local pos = self.object:getpos()
        pos.x = math.floor(pos.x+0.5)
        pos.y = math.floor(pos.y+0.5)
        pos.z = math.floor(pos.z+0.5)
        do_tnt_physics(pos, IRON_TNT_RANGE)
        minetest.sound_play("nuke_explode", {pos = pos,gain = 1.0,max_hear_distance = 16,})
        if minetest.get_node(pos).name == "default:water_source" or minetest.get_node(pos).name == "default:water_flowing" then
            -- Cancel the Explosion
            self.object:remove()
            return
        end
        for x=-WALLBREAK_TNT_RANGE,WALLBREAK_TNT_RANGE do
        for y=-WALLBREAK_TNT_RANGE,WALLBREAK_TNT_RANGE do
        for z=-WALLBREAK_TNT_RANGE,WALLBREAK_TNT_RANGE do
            if x*x+y*y+z*z <= WALLBREAK_TNT_RANGE * WALLBREAK_TNT_RANGE + WALLBREAK_TNT_RANGE then
                local np={x=pos.x+x,y=pos.y+y,z=pos.z+z}
                local n = minetest.get_node(np)
                if n.name ~= "air" then
                    minetest.remove_node(np)
                end
                activate_if_tnt(n.name, np, pos, WALLBREAK_TNT_RANGE)
            end
        end
        end
        end
		self.object:remove()
	end
end

function WALLBREAK_TNT:on_punch(hitter)
	self.health = self.health - 1
	if self.health <= 0 then
		self.object:remove()
		hitter:get_inventory():add_item("main", "atomic_nuke:wallbreak_tnt")
	end
end

minetest.register_entity("atomic_nuke:wallbreak_tnt", WALLBREAK_TNT)

-- Atomic TNT

minetest.register_craft({
	output = 'atomic_nuke:atomic_tnt 5',
	recipe = {
		{'','default:wood 1',''},
		{'default:coal_lump 1','default:mese_crystal 1','default:coal_lump 1'},
		{'','default:cobble 1',''}
	}
})

minetest.register_node("atomic_nuke:atomic_tnt", {
	tile_images = {"nuke_mese_tnt_top.png", "nuke_mese_tnt_bottom.png",
			"nuke_mese_tnt_side.png", "nuke_mese_tnt_side.png",
			"nuke_mese_tnt_side.png", "nuke_mese_tnt_side.png"},
	inventory_image = minetest.inventorycube("nuke_mese_tnt_top.png",
			"nuke_mese_tnt_side.png", "nuke_mese_tnt_side.png"),
	dug_item = '', -- Get nothing
	diggable = false,
	description = "Atomic TNT",
	mesecons = {
		effector = {
			action_on = function(pos, node)
				minetest.remove_node(pos)
				spawn_tnt(pos, node.name)
				nodeupdate(pos)
			end,
			action_off = function(pos, node) end,
			action_change = function(pos, node) end,
		},
	},
	on_punch = function(pos, node, puncher)
		minetest.remove_node(pos)
		spawn_tnt(pos, node.name)
		nodeupdate(pos)
	end,
})

local ATOMIC_TNT_RANGE = 20
local ATOMIC_TNT = {
	-- Static definition
	physical = true, -- Collides with things
	-- weight = 1,
	collisionbox = {-0.5,-0.5,-0.5, 0.5,0.5,0.5},
	visual = "cube",
	textures = {"nuke_mese_tnt_top.png", "nuke_mese_tnt_bottom.png",
			"nuke_mese_tnt_side.png", "nuke_mese_tnt_side.png",
			"nuke_mese_tnt_side.png", "nuke_mese_tnt_side.png"},
	-- Initial value for our timer
	timer = 0,
	-- Number of punches required to defuse
	health = 1000,
	blinktimer = 0,
	blinkstatus = true,
}

function ATOMIC_TNT:on_activate(staticdata)
	self.object:setvelocity({x=0, y=4, z=0})
	self.object:setacceleration({x=0, y=-10, z=0})
	self.object:settexturemod("^[brighten")
end

function ATOMIC_TNT:on_step(dtime)
	self.timer = self.timer + dtime
	self.blinktimer = self.blinktimer + dtime
    if self.timer>5 then
        self.blinktimer = self.blinktimer + dtime
        if self.timer>8 then
            self.blinktimer = self.blinktimer + dtime
            self.blinktimer = self.blinktimer + dtime
        end
    end
	if self.blinktimer > 0.5 then
		self.blinktimer = self.blinktimer - 0.5
		if self.blinkstatus then
			self.object:settexturemod("")
		else
			self.object:settexturemod("^[brighten")
		end
		self.blinkstatus = not self.blinkstatus
	end
	if self.timer > 10 then
		local pos = self.object:getpos()
        pos.x = math.floor(pos.x+0.5)
        pos.y = math.floor(pos.y+0.5)
        pos.z = math.floor(pos.z+0.5)
        do_tnt_physics(pos, ATOMIC_TNT_RANGE)
        minetest.sound_play("nuke_explode", {pos = pos,gain = 1.0,max_hear_distance = 16,})
        if minetest.get_node(pos).name == "default:water_source" or minetest.get_node(pos).name == "default:water_flowing" then
            -- Cancel the Explosion
            self.object:remove()
            return
        end
        for x=-ATOMIC_TNT_RANGE,ATOMIC_TNT_RANGE do
        for y=-ATOMIC_TNT_RANGE,ATOMIC_TNT_RANGE do
        for z=-ATOMIC_TNT_RANGE,ATOMIC_TNT_RANGE do
            if x*x+y*y+z*z <= ATOMIC_TNT_RANGE * ATOMIC_TNT_RANGE + ATOMIC_TNT_RANGE then
                local np={x=pos.x+x,y=pos.y+y,z=pos.z+z}
                local n = minetest.get_node(np)
                if n.name ~= "air" then
                    minetest.remove_node(np)
                end
                activate_if_tnt(n.name, np, pos, ATOMIC_TNT_RANGE)
            end
        end
        end
        end
		self.object:remove()
	end
end

function ATOMIC_TNT:on_punch(hitter)
	self.health = self.health - 1
	if self.health <= 0 then
		self.object:remove()
		hitter:get_inventory():add_item("main", "atomic_nuke:atomic_tnt")
	end
end

minetest.register_entity("atomic_nuke:atomic_tnt", ATOMIC_TNT)

-- Hardcore Wallbreak TNT

minetest.register_craft({
	output = 'atomic_nuke:hardcore_wallbreak_tnt 5',
	recipe = {
		{'','default:wood 1',''},
		{'default:cobble 1','atomic_nuke:wallbreak_tnt 1','default:cobble 1'},
		{'','default:wood 1',''}
	}
})

minetest.register_node("atomic_nuke:hardcore_wallbreak_tnt", {
	tile_images = {"nuke_iron_tnt_top.png", "nuke_iron_tnt_bottom.png",
			"nuke_hardcore_iron_tnt_side.png", "nuke_hardcore_iron_tnt_side.png",
			"nuke_hardcore_iron_tnt_side.png", "nuke_hardcore_iron_tnt_side.png"},
	inventory_image = minetest.inventorycube("nuke_iron_tnt_top.png",
			"nuke_hardcore_iron_tnt_side.png", "nuke_hardcore_iron_tnt_side.png"),
	dug_item = '', -- Get nothing
	diggable = false,
	description = "Hardcore Wallbreak TNT",
	mesecons = {
		effector = {
			action_on = function(pos, node)
				minetest.remove_node(pos)
				spawn_tnt(pos, node.name)
				nodeupdate(pos)
			end,
			action_off = function(pos, node) end,
			action_change = function(pos, node) end,
		},
	},
	on_punch = function(pos, node, puncher)
		minetest.remove_node(pos)
		spawn_tnt(pos, node.name)
		nodeupdate(pos)
	end,
})

local HARDCORE_WALLBREAK_TNT_RANGE = 1
local HARDCORE_WALLBREAK_TNT = {
	-- Static definition
	physical = true, -- Collides with things
	-- weight = 18,
	collisionbox = {-0.5,-0.5,-0.5, 0.5,0.5,0.5},
	visual = "cube",
	textures = {"nuke_iron_tnt_top.png", "nuke_iron_tnt_bottom.png",
			"nuke_hardcore_iron_tnt_side.png", "nuke_hardcore_iron_tnt_side.png",
			"nuke_hardcore_iron_tnt_side.png", "nuke_hardcore_iron_tnt_side.png"},
	-- Initial value for our timer
	timer = 0,
	-- Number of punches required to defuse
	health = 1,
	blinktimer = 0,
	blinkstatus = true,
}

function HARDCORE_WALLBREAK_TNT:on_activate(staticdata)
	self.object:setvelocity({x=0, y=4, z=0})
	self.object:setacceleration({x=0, y=-10, z=0})
	self.object:settexturemod("^[brighten")
end

function HARDCORE_WALLBREAK_TNT:on_step(dtime)
	self.timer = self.timer + dtime
	self.blinktimer = self.blinktimer + dtime
    if self.timer>5 then
        self.blinktimer = self.blinktimer + dtime
        if self.timer>8 then
            self.blinktimer = self.blinktimer + dtime
            self.blinktimer = self.blinktimer + dtime
        end
    end
	if self.blinktimer > 0.5 then
		self.blinktimer = self.blinktimer - 0.5
		if self.blinkstatus then
			self.object:settexturemod("")
		else
			self.object:settexturemod("^[brighten")
		end
		self.blinkstatus = not self.blinkstatus
	end
	if self.timer > 10 then
		local pos = self.object:getpos()
        pos.x = math.floor(pos.x+0.5)
        pos.y = math.floor(pos.y+0.5)
        pos.z = math.floor(pos.z+0.5)
        minetest.sound_play("nuke_explode", {pos = pos,gain = 1.0,max_hear_distance = 16,})
        for x=-HARDCORE_WALLBREAK_TNT_RANGE,HARDCORE_WALLBREAK_TNT_RANGE do
        for z=-HARDCORE_WALLBREAK_TNT_RANGE,HARDCORE_WALLBREAK_TNT_RANGE do
            if x*x+z*z <= HARDCORE_WALLBREAK_TNT_RANGE * HARDCORE_WALLBREAK_TNT_RANGE + HARDCORE_WALLBREAK_TNT_RANGE then
                local np={x=pos.x+x,y=pos.y,z=pos.z+z}
                minetest.add_entity(np, "atomic_nuke:wallbreak_tnt")
            end
        end
        end
		self.object:remove()
	end
end

function HARDCORE_WALLBREAK_TNT:on_punch(hitter)
	self.health = self.health - 1
	if self.health <= 0 then
		self.object:remove()
		hitter:get_inventory():add_item("main", "atomic_nuke:hardcore_wallbreak_tnt 1")
	end
end

minetest.register_entity("atomic_nuke:hardcore_wallbreak_tnt", HARDCORE_WALLBREAK_TNT)

-- Hardcore Atomic TNT

minetest.register_craft({
	output = 'atomic_nuke:hardcore_atomic_tnt 5',
	recipe = {
		{'','default:wood 1',''},
		{'default:cobble 1','atomic_nuke:mese_tnt 1','default:cobble 1'},
		{'','default:wood 1',''}
	}
})

minetest.register_node("atomic_nuke:hardcore_atomic_tnt", {
	tile_images = {"nuke_mese_tnt_top.png", "nuke_mese_tnt_bottom.png",
			"nuke_hardcore_mese_tnt_side.png", "nuke_hardcore_mese_tnt_side.png",
			"nuke_hardcore_mese_tnt_side.png", "nuke_hardcore_mese_tnt_side.png"},
	inventory_image = minetest.inventorycube("nuke_mese_tnt_top.png",
			"nuke_hardcore_mese_tnt_side.png", "nuke_hardcore_mese_tnt_side.png"),
	dug_item = '', -- Get nothing
	diggable = false,
	description = "Hardcore Atomic TNT",
	mesecons = {
		effector = {
			action_on = function(pos, node)
				minetest.remove_node(pos)
				spawn_tnt(pos, node.name)
				nodeupdate(pos)
			end,
			action_off = function(pos, node) end,
			action_change = function(pos, node) end,
		},
	},
	on_punch = function(pos, node, puncher)
		minetest.remove_node(pos)
		spawn_tnt(pos, node.name)
		nodeupdate(pos)
	end,
})

local HARDCORE_AOMIC_TNT_RANGE = 1
local HARDCORE_ATOMIC_TNT = {
	-- Static definition
	physical = true, -- Collides with things
	-- weight = 2,
	collisionbox = {-0.5,-0.5,-0.5, 0.5,0.5,0.5},
	visual = "cube",
	textures = {"nuke_mese_tnt_top.png", "nuke_mese_tnt_bottom.png",
			"nuke_hardcore_mese_tnt_side.png", "nuke_hardcore_mese_tnt_side.png",
			"nuke_hardcore_mese_tnt_side.png", "nuke_hardcore_mese_tnt_side.png"},
	-- Initial value for our timer
	timer = 0,
	-- Number of punches required to defuse
	health = 1,
	blinktimer = 0,
	blinkstatus = true,
}

function HARDCORE_ATOMIC_TNT:on_activate(staticdata)
	self.object:setvelocity({x=0, y=4, z=0})
	self.object:setacceleration({x=0, y=-10, z=0})
	self.object:settexturemod("^[brighten")
end

function HARDCORE_ATOMIC_TNT:on_step(dtime)
	self.timer = self.timer + dtime
	self.blinktimer = self.blinktimer + dtime
    if self.timer>5 then
        self.blinktimer = self.blinktimer + dtime
        if self.timer>8 then
            self.blinktimer = self.blinktimer + dtime
            self.blinktimer = self.blinktimer + dtime
        end
    end
	if self.blinktimer > 0.5 then
		self.blinktimer = self.blinktimer - 0.5
		if self.blinkstatus then
			self.object:settexturemod("")
		else
			self.object:settexturemod("^[brighten")
		end
		self.blinkstatus = not self.blinkstatus
	end
	if self.timer > 10 then
		local pos = self.object:getpos()
        pos.x = math.floor(pos.x+0.5)
        pos.y = math.floor(pos.y+0.5)
        pos.z = math.floor(pos.z+0.5)
        minetest.sound_play("nuke_explode", {pos = pos,gain = 1.0,max_hear_distance = 16,})
        for x=-HARDCORE_ATOMIC_TNT_RANGE,HARDCORE_ATOMIC_TNT_RANGE do
        for z=-HARDCORE_ATOMIC_TNT_RANGE,HARDCORE_ATOMIC_TNT_RANGE do
            if x*x+z*z <= HARDCORE_ATOMIC_TNT_RANGE * HARDCORE_ATOMIC_TNT_RANGE + HARDCORE_ATOMIC_TNT_RANGE then
                local np={x=pos.x+x,y=pos.y,z=pos.z+z}
                minetest.add_entity(np, "atomic_nuke:atomic_tnt")
            end
        end
        end
		self.object:remove()
	end
end

function HARDCORE_ATOMIC_TNT:on_punch(hitter)
	self.health = self.health - 1
	if self.health <= 0 then
		self.object:remove()
		hitter:get_inventory():add_item("main", "atomic_nuke:hardcore_atomic_tnt 1")
	end
end

minetest.register_entity("atomic_nuke:hardcore_atomic_tnt", HARDCORE_ATOMIC_TNT)

-- DIABOLIC TNT

minetest.register_craft({
	output = 'atomic_nuke:diabolic_tnt 5',
	recipe = {
		{'','default:wood 1',''},
		{'default:coal_lump 1','default:mese_block 1','default:coal_lump 1'},
		{'','default:cobble 1',''}
	}
})

minetest.register_node("atomic_nuke:diabolic_tnt", {
	tile_images = {"nuke_hardcor_mese_tnt_top.png", "nuke_hardcore_mese_tnt_bottom.png",
			"nuke_hardcore_mese_tnt_side.png", "nuke_hardcore_mese_tnt_side.png",
			"nuke_hardcore_mese_tnt_side.png", "nuke_hardcore_mese_tnt_side.png"},
	inventory_image = minetest.inventorycube("nuke_hardcore_mese_tnt_top.png",
			"nuke_mese_tnt_side.png", "nuke_hardcore_mese_tnt_side.png"),
	dug_item = '', -- Get nothing
	diggable = false,
	description = "Diabolic TNT",
	mesecons = {
		effector = {
			action_on = function(pos, node)
				minetest.remove_node(pos)
				spawn_tnt(pos, node.name)
				nodeupdate(pos)
			end,
			action_off = function(pos, node) end,
			action_change = function(pos, node) end,
		},
	},
	on_punch = function(pos, node, puncher)
		minetest.remove_node(pos)
		spawn_tnt(pos, node.name)
		nodeupdate(pos)
	end,
})

local DIABOLIC_TNT_RANGE = 40
local DIABOLIC_TNT = {
	-- Static definition
	physical = true, -- Collides with things
	-- weight = 1,
	collisionbox = {-0.5,-0.5,-0.5, 0.5,0.5,0.5},
	visual = "cube",
	textures = {"nuke_hardcore_mese_tnt_top.png", "nuke_hardcore_mese_tnt_bottom.png",
			"nuke_hardcore_mese_tnt_side.png", "nuke_hardcore_mese_tnt_side.png",
			"nuke_hardcore_mese_tnt_side.png", "nuke_hardcore_mese_tnt_side.png"},
	-- Initial value for our timer
	timer = 0,
	-- Number of punches required to defuse
	health = 1000,
	blinktimer = 0,
	blinkstatus = true,
}

function DIABOLIC_TNT:on_activate(staticdata)
	self.object:setvelocity({x=0, y=4, z=0})
	self.object:setacceleration({x=0, y=-10, z=0})
	self.object:settexturemod("^[brighten")
end

function DIABOLIC_TNT:on_step(dtime)
	self.timer = self.timer + dtime
	self.blinktimer = self.blinktimer + dtime
    if self.timer>5 then
        self.blinktimer = self.blinktimer + dtime
        if self.timer>8 then
            self.blinktimer = self.blinktimer + dtime
            self.blinktimer = self.blinktimer + dtime
        end
    end
	if self.blinktimer > 0.5 then
		self.blinktimer = self.blinktimer - 0.5
		if self.blinkstatus then
			self.object:settexturemod("")
		else
			self.object:settexturemod("^[brighten")
		end
		self.blinkstatus = not self.blinkstatus
	end
	if self.timer > 10 then
		local pos = self.object:getpos()
        pos.x = math.floor(pos.x+0.5)
        pos.y = math.floor(pos.y+0.5)
        pos.z = math.floor(pos.z+0.5)
        do_tnt_physics(pos, ATOMIC_TNT_RANGE)
        minetest.sound_play("nuke_explode", {pos = pos,gain = 1.0,max_hear_distance = 16,})
        if minetest.get_node(pos).name == "yum:lemon_donut" or minetest.get_node(pos).name == "yum:chocolate_donut" then
            -- Cancel the Explosion
            self.object:remove()
            return
        end
        for x=-DIABOLIC_TNT_RANGE,DIABOLIC_TNT_RANGE do
        for y=-DIABOLIC_TNT_RANGE,DIABOLIC_TNT_RANGE do
        for z=-DIABOLIC_TNT_RANGE,DIABOLIC_TNT_RANGE do
            if x*x+y*y+z*z <= DIABOLIC_TNT_RANGE * DIABOLIC_TNT_RANGE + DIABOLIC_TNT_RANGE then
                local np={x=pos.x+x,y=pos.y+y,z=pos.z+z}
                local n = minetest.get_node(np)
                if n.name ~= "air" then
                    minetest.remove_node(np)
                end
                activate_if_tnt(n.name, np, pos, DIABOLIC_TNT_RANGE)
            end
        end
        end
        end
		self.object:remove()
	end
end

function DIABOLIC_TNT:on_punch(hitter)
	self.health = self.health - 1
	if self.health <= 0 then
		self.object:remove()
		hitter:get_inventory():add_item("main", "atomic_nuke:diabolic_tnt")
	end
end

minetest.register_entity("atomic_nuke:diabolic_tnt", DIABOLIC_TNT)



-- HALT TNT

minetest.register_craft({
	output = 'atomic_nuke:halt_tnt 5',
	recipe = {
		{'default:diamond 1','default:wood 1','default:diamond 1'},
		{'default:coal_lump 1','default:mese_block 1','default:coal_lump 1'},
		{'default:diamond 1','default:cobble 1','default:diamond 1'}
	}
})

minetest.register_node("atomic_nuke:halt_tnt", {
	tile_images = {"nuke_hardcore_iron_tnt_top.png", "nuke_hardcore_iron_tnt_bottom.png",
			"nuke_hardcore_iron_tnt_side.png", "nuke_hardcore_iron_tnt_side.png",
			"nuke_hardcore_iron_tnt_side.png", "nuke_hardcore_iron_tnt_side.png"},
	inventory_image = minetest.inventorycube("nuke_hardcore_iron_tnt_top.png",
			"nuke_hardcore_iron_tnt_side.png", "nuke_hardcore_iron_tnt_side.png"),
	dug_item = '', -- Get nothing
	diggable = false,
	description = "Halt TNT",
	mesecons = {
		effector = {
			action_on = function(pos, node)
				minetest.remove_node(pos)
				spawn_tnt(pos, node.name)
				nodeupdate(pos)
			end,
			action_off = function(pos, node) end,
			action_change = function(pos, node) end,
		},
	},
	on_punch = function(pos, node, puncher)
		minetest.remove_node(pos)
		spawn_tnt(pos, node.name)
		nodeupdate(pos)
	end,
})

local HALT_TNT_RANGE = 80
local HALT_TNT = {
	-- Static definition
	physical = true, -- Collides with things
	-- weight = 1,
	collisionbox = {-0.5,-0.5,-0.5, 0.5,0.5,0.5},
	visual = "cube",
	textures = {"nuke_hardcore_iron_tnt_top.png", "nuke_hardcore_iron_tnt_bottom.png",
			"nuke_hardcore_iron_tnt_side.png", "nuke_hardcore_iron_tnt_side.png",
			"nuke_hardcore_iron_tnt_side.png", "nuke_hardcore_iron_tnt_side.png"},
	-- Initial value for our timer
	timer = 0,
	-- Number of punches required to defuse
	health = 1000000,
	blinktimer = 0,
	blinkstatus = true,
}

function HALT_TNT:on_activate(staticdata)
	self.object:setvelocity({x=0, y=4, z=0})
	self.object:setacceleration({x=0, y=-10, z=0})
	self.object:settexturemod("^[brighten")
end

function HALT_TNT:on_step(dtime)
	self.timer = self.timer + dtime
	self.blinktimer = self.blinktimer + dtime
    if self.timer>5 then
        self.blinktimer = self.blinktimer + dtime
        if self.timer>8 then
            self.blinktimer = self.blinktimer + dtime
            self.blinktimer = self.blinktimer + dtime
        end
    end
	if self.blinktimer > 0.5 then
		self.blinktimer = self.blinktimer - 0.5
		if self.blinkstatus then
			self.object:settexturemod("")
		else
			self.object:settexturemod("^[brighten")
		end
		self.blinkstatus = not self.blinkstatus
	end
	if self.timer > 10 then
		local pos = self.object:getpos()
        pos.x = math.floor(pos.x+0.5)
        pos.y = math.floor(pos.y+0.5)
        pos.z = math.floor(pos.z+0.5)
        do_tnt_physics(pos, HALT_TNT_RANGE)
        minetest.sound_play("nuke_explode", {pos = pos,gain = 1.0,max_hear_distance = 100,})
        if minetest.get_node(pos).name == "default:diamond_block" or minetest.get_node(pos).name == "default:mese_block" then
            -- Cancel the Explosion
            self.object:remove()
            return
        end
        for x=-HALT_TNT_RANGE,HALT_TNT_RANGE do
        for y=-HALT_TNT_RANGE,HALT_TNT_RANGE do
        for z=-HALT_TNT_RANGE,HALT_TNT_RANGE do
            if x*x+y*y+z*z <= HALT_TNT_RANGE * HALT_TNT_RANGE + HALT_TNT_RANGE then
                local np={x=pos.x+x,y=pos.y+y,z=pos.z+z}
                local n = minetest.get_node(np)
                if n.name ~= "air" then
                    minetest.remove_node(np)
                end
                activate_if_tnt(n.name, np, pos, HALT_TNT_RANGE)
            end
        end
        end
        end
		self.object:remove()
	end
end

function HALT_TNT:on_punch(hitter)
	self.health = self.health - 1
	if self.health <= 0 then
		self.object:remove()
		hitter:get_inventory():add_item("main", "atomic_nuke:halt_tnt")
	end
end

minetest.register_entity("atomic_nuke:halt_tnt", HALT_TNT)



