This mod is released under WTFPL.
It adds ability to:
- kill other players by using /kill command which requires "kill" privilege;
- set other player's HP to a different values.
