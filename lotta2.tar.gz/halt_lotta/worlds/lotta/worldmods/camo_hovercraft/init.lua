dofile(minetest.get_modpath("camo_hovercraft").."/hover.lua")

hover:register_hovercraft("camo_hovercraft:hover_green_camo" ,{
	description = "Green Camo Hovercraft",
	textures = {"camo_green.png^hover_base.png"},
	inventory_image = "hovercraft_green_camo_inv.png",
	max_speed = 14,
        stepheight = 1.1,
	acceleration = 0.25,
	deceleration = 0.05,
	jump_velocity = 6,
	fall_velocity = 4,
	bounce = 0.1,
})

police:register_hovercraft("camo_hovercraft:hover_police" ,{
	description = "Police Hovercraft",
	textures = {"camo_police.png^hover_base.png"},
	inventory_image = "hovercraft_blue_camo_inv.png",
	max_speed = 40,
        stepheight = 1.1,
	acceleration = 0.50,
	deceleration = 90.01,
	jump_velocity = 15,
	fall_velocity = 5,
	bounce = 0.01,
})

hover:register_hovercraft("camo_hovercraft:hover_yellow_camo" ,{
	description = "Yellow Camo Hovercraft",
	textures = {"camo_yellow.png^hover_base.png"},
	inventory_image = "hovercraft_yellow_camo_inv.png",
	max_speed = 14,
        stepheight = 1.1,
	acceleration = 0.25,
	deceleration = 0.05,
	jump_velocity = 6,
	fall_velocity = 4,
	bounce = 0.1,
})

hover:register_hovercraft("camo_hovercraft:hover_red_camo" ,{
	description = "Red Camo Hovercraft",
	textures = {"camo_red.png^hover_base.png"},
	inventory_image = "hovercraft_red_camo_inv.png",
	max_speed = 14,
	stepheight = 1.1,
	acceleration = 0.25,
	deceleration = 0.05,
	jump_velocity = 6,
	fall_velocity = 4,
	bounce = 0.1,
})

hover:register_hovercraft("camo_hovercraft:hover_blue_camo" ,{
	description = "Blue Camo Hovercraft",
	textures = {"camo_blue.png^hover_base.png"},
	inventory_image = "hovercraft_blue_camo_inv.png",
	max_speed = 14,
	stepheight = 1.1,
	acceleration = 0.25,
	deceleration = 0.05,
	jump_velocity = 6,
	fall_velocity = 4,
	bounce = 0.1,
})

hover:register_hovercraft("camo_hovercraft:hover_urban_camo" ,{
	description = "Urban Camo Hovercraft",
	textures = {"camo_urban.png^hover_base.png"},
	inventory_image = "hovercraft_urban_camo_inv.png",
	max_speed = 14,
	stepheight = 1.1,
	acceleration = 0.25,
	deceleration = 0.05,
	jump_velocity = 6,
	fall_velocity = 4,
	bounce = 0.1,
})

hover:register_hovercraft("camo_hovercraft:hover_special_ops" ,{
	description = "Black Special Ops Hovercraft",
	textures = {"black.png^hover_base.png"},
	inventory_image = "hovercraft_special_ops_inv.png",
	max_speed = 14,
	stepheight = 1.1,
	acceleration = 0.25,
	deceleration = 0.05,
	jump_velocity = 6,
	fall_velocity = 4,
	bounce = 0.1,
})

