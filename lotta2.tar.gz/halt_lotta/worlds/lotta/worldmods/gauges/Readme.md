This mod adds:
- HP bars floating above the players;
- "progress" bars above the furnaces.

Keep in mind, that to make gauges for furnaces I had to change the "default" mod.
Take the "init.lua from the "default" folder from this mod and replace original 
one of the "default" mod in minetest_game.

Is anyone know how to override ABM then let me know and I would do this w/o editing
default things ;)
