player_notes
============

Player notes mod for Minetest

License for everything: WTFPL