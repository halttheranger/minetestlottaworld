This mod is released under WTFPL.  
It adds ability to teleport to other players with their permission by using the /tpr command which requires "interact" privilege and the /tphr command which requires the "interact " privilege.
