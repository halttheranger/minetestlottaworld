#!/bin/bash

rm -fr *~ *.old players* areas.dat
rm -fr auth.txt ipban.txt ipnames* xban.db
rm -fr chatplus.txt future_banlist.txt last-seen
rm -fr gates home npc_data online-players schems
rm -fr mesecon_actionqueue
rm -fr mod_travelnet.data
