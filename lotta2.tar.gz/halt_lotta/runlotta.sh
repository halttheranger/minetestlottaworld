#!/bin/bash

cat >/dev/null <<END

1. LOTTA is a complete little version of LOTT, Lord of the Test.  This
is release 160112. It includes spawn, the satellite, and the wiki.

2. On most  Linux  machines  with  Minetest installed,  if you set the
first parameter indicated below correctly,  SERVEREXE,  and  run  this
script as root, this script should start LOTTA.

LOTTA should work with both "system install" and "run-in-place" copies
of Minetest.

The program  should also work if  you run it as an ordinary user,  but
this isn't guaranteed.

In short, LOTTA is magic. Disclaimer: LOTTA is not magic.

3. The one setting that you must check and change  is named SERVEREXE.
You'll see a line like this in the parameters section:

SERVEREXE=/usr/bin/minetest

If a "minetest" executable is installed on your system,  set SERVEREXE
to an absolute path for that executable.

If you have "minetestserver"  and not "minetest",  specify an absolute
path for "minetestserver" instead.

4. Minetest 0.4.13  or  above is required.  Additionally,  you'll need
to execute the  startup script using bash. sh won't work.

The startup script is named "runlotta.sh".  To run LOTTA  as  a  fore-
ground process, edit the script and set SERVEREXE  correctly,  then go
to the folder containing the script and execute:

    ./runlotta.sh
or:
    bash ./runlotta.sh

To run LOTTA as a background process, add & at the end of the line:

    ./runlotta.sh &
or:
    bash ./runlotta.sh &

The world should run on the port specified by WORLDPORT in the parame-
ters section.

5. Log files are saved in a subdirectory named "/var/tmp/lotta".

6. If  you can't make LOTTA work using this script,  move these pieces
to the  appropriate locations and run it using usual  Minetest proced-
ures:

(a) games/lotta_game - This is the "_game" folder
(b) worlds/lotta     - This is the world   folder
(c) world.conf       - Use this to replace your "minetest.conf" file

7. Optional:  In the parameters section, set this parameter to the de-
sired port number:

WORLDPORT=30050

Edit "world.conf" and make the same change to the  "port" parameter in
that file.

These  additional setup steps are  recommended,  but may not be essen-
tial. They require Linux CLI expertise.

8. If you have root access,  and if your Minetest executable is set up
to run  as a specific user and group,  execute chown -R games.games on
the  LOTTA directory tree,  substituting  the appropriate "user.group"
for "games.games".

9. Execute chmod -R a+w on the same directory tree.

10. By default,  the world owner is  "Gandalf".  To change this,  edit
"world.conf" and modify the "name" setting.

END

#---------------------------------------------------------------------
# Parameters.

SERVEREXE=/usr/bin/minetest
WORLDPORT=30050

#---------------------------------------------------------------------
# This is a LOTTA setup.

ls -l $SERVEREXE                                        || exit 1

THISDIR="$( dirname ${BASH_SOURCE[0]} )"
cd $THISDIR                                             || exit 1
BESTDIR=`pwd`                                           || exit 1

LOTTADIR=/var/tmp/lotta
HOME=$LOTTADIR
export HOME

mkdir -p  $LOTTADIR                                     || exit 1
chmod 777 $LOTTADIR                                     || exit 1

WORLDDIR=$BESTDIR/worlds/lotta

# Absolute path for world's ".conf" file
WORLDCONF=$BESTDIR/world.conf

ls -l $WORLDDIR/map.sqlite                              || exit 1
ls -l $WORLDCONF                                        || exit 1

MINETEST_SUBGAME_PATH=$BESTDIR/games
ls -l $MINETEST_SUBGAME_PATH/lotta_game/game.conf       || exit 1
export MINETEST_SUBGAME_PATH

chmod -R a+w         $BESTDIR > /dev/null 2>&1
chown -R games.games $BESTDIR > /dev/null 2>&1
ulimit -a                     > /dev/null 2>&1

touch     $LOTTADIR/debug-lotta.log                     || exit 1
touch     $LOTTADIR/lotta.log                           || exit 1
mkdir -p  $LOTTADIR/.minetest                           || exit 1
chmod 777 $LOTTADIR/.minetest                           || exit 1
chmod a+w $LOTTADIR/*                                   || exit 1

SERVERSWITCH=
if [ `basename $SERVEREXE` == "minetest" ]; then
    SERVERSWITCH=--server
fi

#---------------------------------------------------------------------
# Time to run for fun.

$SERVEREXE \
$SERVERSWITCH                           \
--port    $WORLDPORT                    \
--config  $WORLDCONF                    \
--gameid  lotta_game                    \
--logfile $LOTTADIR/debug-lotta.log     \
--world   $WORLDDIR                     \
>> $LOTTADIR/lotta.log 2>&1
