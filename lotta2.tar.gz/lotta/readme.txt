For documentation and instructions, see the comments in "runlotta.sh".
