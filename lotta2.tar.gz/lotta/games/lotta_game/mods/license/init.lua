
minetest.register_tool("license:license", {
	description = "Drivers license",
	inventory_image = "license_license.png",
	tool_capabilities = {
		full_punch_interval = 1.2,
		max_drop_level=0,
		groupcaps={
			cracky = {times={[3]=1.60}, uses=1, maxlevel=1},
		},
		damage_groups = {fleshy=1},
	},
})
