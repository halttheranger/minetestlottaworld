unified_inventory
=================

Replacement for Minetest creative inventory.

Unified Inventory replaces the survival and creative inventory; it also functions as a crafting guide.
